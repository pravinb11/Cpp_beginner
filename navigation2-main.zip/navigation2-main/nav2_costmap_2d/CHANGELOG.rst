^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package nav2_costmap_2d
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

(2018-10-9)
-------------------
* Port nav2_costmap_2d from costmap_2d version 1.16.2 (2018-07-31) 
